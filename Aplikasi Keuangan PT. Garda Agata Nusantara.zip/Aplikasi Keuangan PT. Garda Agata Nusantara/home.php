<?php

	require_once'function/koneksi.php';




  ?>



<!DOCTYPE html>
<html>
<head>
	<title>TUGAS KP</title>
</head>
<body>
	<a href="input.php">INPUTDATA</a><br>
		<a href="tampil.php">Tampil Data</a>

</body>
</html>