<?php 

	require_once'function/koneksi.php';

 ?>




<!DOCTYPE html>
<html>
<head>
	<title>Tampil Barang</title>
</head>
<body>




	<?php 

// * = adalah semua jika mau satu satu ketik saja variable yang ada 
//
		$sql = "SELECT * FROM data_barang";
		$query = mysqli_query($koneksi, $sql);	

		if(mysqli_num_rows($query)== 0) {
			echo "Gagal menampilkan data";
		
		}else{


		

	 ?>
	 <a href="index.php">Menu<br></a>
	<table border="1">
		<thead>
		<tr>
				<th>No.</th>
				<th>Kode Barang</th>
				<th>Nama Barang</th>
				<th>Quantity</th>
				<th>Lokasi Penyimpanan</th>
				<th>aksi</th>
		</tr>
	</thead>

		<?php 
		$no = 1;
		while($row = mysqli_fetch_assoc($query)){
		 ?>


		<tbody> <tr>
			<td> <?php echo $no;                  ?>  </td>
			<td> <?php echo $row ['kode_barang']; ?>  </td>
			<td> <?php echo $row ['nama_barang']; ?>  </td>
			<td> <?php echo $row ['quantity'];    ?>  </td>
			<td> <?php echo $row ['lokasi'];      ?>  </td>
			<td><a href="edit.php?id_barang=<?= $row['id_barang'];?>" >Edit</a> | 
			 <a href="hapus.php?id_barang=<?php echo $row['id_barang']; ?>">Hapus</a>

	</tr>
	</tbody>
	<?php $no++; } ?>
	</table>
<?php  } ?>
</body>
</html>