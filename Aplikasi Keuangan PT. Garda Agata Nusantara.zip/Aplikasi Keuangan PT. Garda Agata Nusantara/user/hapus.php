<?php
require_once '../function/koneksi.php';


$id_login = $_GET['id_login'];

mysqli_query($koneksi, "DELETE FROM admin WHERE id_login = '$id_login'") or die("Gagal menghapus database");

//echo '';
header("location:user.php?data=hapus");
