<html lang="en">

<head>
    <title>
        cetak laporan pemasukan
    </title>
</head>
<style>
    body {
        font-family: 'Times New Roman', Times, serif;
    }

    th {
        background-color: red;
        color: white;
    }
</style>

<body>
    <img src="../logo.png" style="position: absolute; width: 50px; height:auto">
    <table style="width: 100%;">
        <tr>
            <td align="center">
                <span style="line-height: 1.6; font-weight: bold;">
                    LAPORAN PENDAPATAN <BR>PT. GARDA NUSANTARA
                </span>
            </td>
        </tr>
    </table>
    <hr size="2" color="black">
    <!-- <center>
        <H5><b>TABEL PRAKTIKAN</b></H5>
    </center> -->

    <?php

    require_once '../function/koneksi.php';

    session_start();
    if ($_SESSION['status'] != "login") {
        header("location: ../dist/index.php?pesan=belum_login");
    }

    // $sql = "SELECT * FROM data_barang $where";
    $sql = "SELECT * FROM data_barang, admin WHERE data_barang.id_login=admin.id_login";
    $query = mysqli_query($koneksi, $sql);

    if (mysqli_num_rows($query) == 0) {
        echo "Tidak ada data untuk ditampilkan";
    } else {

    ?>


        <table border="1" style="font-size: 12px; border-collapse: collapse;" width="100%" cellspacing="0">
            <thead align="center">
                <tr>
                    <th>No</th>
                    <th>Kode pendapatan</th>
                    <th>Pengguna</th>
                    <th>Nama Pendapatan</th>
                    <th>Quantity</th>
                    <th>Tanggal</th>
                    <th>Pendapatan</th>
                </tr>
            </thead>
            <?php

            $totalsaldo = 0;
            $no = 1;
            while ($row = mysqli_fetch_assoc($query)) {
                $totalsaldo += $row['saldo'];
            ?>
                <tbody>
                    <tr>
                        <td align="center"> <?php echo $no; ?> </td>
                        <td> <?php echo $row['kode_barang']; ?> </td>
                        <td><?php echo $row['username']; ?></td>
                        <td> <?php echo $row['nama_barang']; ?> </td>
                        <td align="right"> <?php echo $row['quantity']; ?> </td>
                        <td align="center"> <?php echo $row['tanggal']; ?> </td>
                        <td align="right"> <?php echo 'Rp. ' . $row['saldo']; ?> </td>
                    </tr>
                </tbody>
            <?php $no++;
            } ?>
            <td colspan="6" align="center"> Total Saldo </td>
            <td align="right"> <?php echo 'Rp. ' . $totalsaldo; ?></td>
        </table>
    <?php } ?>

    <script>
        window.print();
    </script>

</body>

</html>