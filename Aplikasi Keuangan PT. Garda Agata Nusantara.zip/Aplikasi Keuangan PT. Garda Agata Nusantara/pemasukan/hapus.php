<?php  
	require_once '../function/koneksi.php';


	$id_barang = $_GET['id_barang'];

	mysqli_query($koneksi,"DELETE FROM data_barang WHERE id_barang = '$id_barang'") or die( "Gagal menghapus database");


		header("location:datamentah.php");
