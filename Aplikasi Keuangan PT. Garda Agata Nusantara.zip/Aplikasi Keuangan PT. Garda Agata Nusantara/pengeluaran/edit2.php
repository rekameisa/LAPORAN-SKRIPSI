<?php

require_once '../function/koneksi.php';
session_start();
if ($_SESSION['status'] != "login") {
    header("location: ../dist/index.php?pesan=belum_login");
}
$level = isset($_SESSION['level']) ? $_SESSION['level'] : false;
$id_jadi = $_GET['id_jadi'];

$sql = "SELECT * FROM data_jadi WHERE id_jadi   = '$id_jadi'";
$query = mysqli_query($koneksi, $sql);
$row = mysqli_fetch_assoc($query);

$kode_barang = $row['kode_barang'];
$id_login = $row['id_login'];
$nama_barang = $row['nama_barang'];
$quantity = $row['quantity'];
$tanggal = $row['tanggal'];
$saldo = $row['saldo'];


if (isset($_POST['submit'])) {

    $kode_barang = $_POST['kode_barang'];
    $id_login = $_POST['id_login'];
    $nama_barang = $_POST['nama_barang'];
    $quantity = $_POST['quantity'];
    $tanggal = $_POST['tanggal'];
    $saldo = $_POST['saldo'];
    header("location: datajadi.php");
}

$queryUpdate = "UPDATE data_jadi SET kode_barang = '$kode_barang', id_login = '$id_login', nama_barang = '$nama_barang', quantity= '$quantity', tanggal= '$tanggal', saldo= '$saldo' WHERE id_jadi= '$id_jadi' ";

$test = mysqli_query($koneksi, $queryUpdate);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <link href="../dist/css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php
    $cari = '';
    $halaman = 'pengeluaran';
    include '../sidebar.php'
    ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Data Pengeluaran</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"></li>
                </ol>

                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table mr-1"></i>

                    </div>

                    <div class="card-body">
                        <form action="" method="post">

                            <div class="form-group">
                                <label>Kode Barang</label>
                                <input type="text" name="kode_barang" required class="form-control" value="<?php echo $row['kode_barang']; ?>">
                            </div>

                            <div class="form-group">
                                <label>Nama Barang</label>
                                <input type="text" name="nama_barang" required class="form-control" value="<?php echo $row['nama_barang']; ?>">
                            </div>

                            <div class="form-group">
                                <label>Quantity</label>
                                <input type="text" name="quantity" required class="form-control" value="<?php echo $row['quantity']; ?>">
                            </div>

                            <div class="form-group">
                                <label>tanggal</label>
                                <input type="date" name="tanggal" required class="form-control" value="<?php echo $row['tanggal']; ?>">
                            </div>

                            <div class="form-group">
                                <label>Saldo</label>
                                <input type="text" name="saldo" required class="form-control" value="<?php echo $row['saldo']; ?>">
                            </div>
                            <input type="hidden" name="id_login" value="<?php echo $_SESSION['id_login']; ?>">
                            <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy; Reka Meisa</div>
                    <div>
                        <a href="#">Privacy Policy</a>
                        &middot;
                        <a href="#">Terms &amp; Conditions</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../dist/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="../dist/assets/demo/chart-area-demo.js"></script>
    <script src="../dist/assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="../dist/assets/demo/datatables-demo.js"></script>
</body>

</html>