
<?php 
		require_once'function/koneksi.php';

	if(isset($_POST['submit'])){
		$kode_barang = $_POST['kode_barang'];
		$nama_barang = $_POST['nama_barang'];
		$quantity = $_POST['quantity'];
		$lokasi = $_POST['lokasi'];

		$sql = "INSERT INTO data_barang(kode_barang, nama_barang, quantity, lokasi) VALUES('$kode_barang', '$nama_barang', '$quantity', '$lokasi')";
		$query = mysqli_query($koneksi, $sql);
		header("location: tampil.php");

	}




 ?>







<!DOCTYPE html>
<html>
<head>
	<title>input</title>
</head>
<body>

<h1>Input Data</h1>

<form action="" method="POST">
	<label>Kode Barang: </label>
	<input type="text" name="kode_barang"><br>
	
	<label>Nama Barang: </label>
	<input type="text" name="nama_barang"><br>

	<label>Quantity: </label>
	<input type="text" name="quantity"><br>

	<label>Lokasi: </label>	
	<input type="text" name="lokasi"><br>

	<button type="submit" name="submit">Submit</button>
	<br>
	<a href="tampil.php">Tampilan Data</a>
</form>

</body>
</html>